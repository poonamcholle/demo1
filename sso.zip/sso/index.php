<?php
/*
Plugin Name: miniOrange PHP SAML 2.0 Connector
Version: 11.0.0
Author: miniOrange
*/
require_once 'connector.php';


header("Location: admin_login.php");
exit();

 ?>